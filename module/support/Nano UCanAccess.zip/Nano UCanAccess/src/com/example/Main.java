package com.example;

import java.sql.*;

/**
 * This program demonstrates how to use UCanAccess JDBC driver to read/write
 * a Microsoft Access database.
 * @author www.codejava.net
 *
 */
public class Main {

  public static void main(String[] args) {

    String databaseURL = "jdbc:ucanaccess://C://Users//XT3-ONE//Documents//GitHub//main//lexicon.accdb";

    try (Connection connection = DriverManager.getConnection(databaseURL)) {

      String sql = "SELECT * FROM [Quantum-Term-Table] WHERE Grammar = 'Fact';";

      Statement statement = connection.createStatement();
      ResultSet result = statement.executeQuery(sql);

      while (result.next()) {
        int id = result.getInt("DataKey");
        String fullname = result.getString("Speech");

        System.out.println(id + ", " + fullname);
      }
    } catch (SQLException ex) {
      ex.printStackTrace();
    }
  }

}
