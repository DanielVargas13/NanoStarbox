function result(){
    return "this is output from my server-side-script-include";
}